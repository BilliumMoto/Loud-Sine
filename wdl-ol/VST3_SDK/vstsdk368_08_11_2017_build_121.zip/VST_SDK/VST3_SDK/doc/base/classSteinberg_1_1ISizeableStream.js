var classSteinberg_1_1ISizeableStream =
[
    [ "getStreamSize", "classSteinberg_1_1ISizeableStream.html#a14a1cf32b76e98f867728d2b140d664c", null ],
    [ "setStreamSize", "classSteinberg_1_1ISizeableStream.html#a6c01cd5e45522b070c29ddc3402c9cbd", null ]
];