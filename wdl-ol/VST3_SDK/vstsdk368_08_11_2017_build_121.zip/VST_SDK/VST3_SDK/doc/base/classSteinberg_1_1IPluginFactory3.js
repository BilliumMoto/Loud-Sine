var classSteinberg_1_1IPluginFactory3 =
[
    [ "getClassInfoUnicode", "classSteinberg_1_1IPluginFactory3.html#a7be60c9a60f393b045b5d48c4d9de6ca", null ],
    [ "setHostContext", "classSteinberg_1_1IPluginFactory3.html#a7fa0087a5cb612e3aeeefa4c91f638c7", null ]
];