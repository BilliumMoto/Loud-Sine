var geoconstants_8h =
[
    [ "Direction", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aa", [
      [ "kNorth", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aaa89c5f7af4c1a4fe20ab7524369050200", null ],
      [ "kNorthEast", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aaa80a10c4928ef7af3ce487d381e2420d2", null ],
      [ "kEast", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aaa37d01669db016bc15ed6fdab6fb6c790", null ],
      [ "kSouthEast", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aaadf50c366ce2690678d0e6290f52b4639", null ],
      [ "kSouth", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aaa515c12ec206b53ce5da86a402b3f4cf8", null ],
      [ "kSouthWest", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aaa6a77137c947ac754a97274617a22afb6", null ],
      [ "kWest", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aaa45b705ff067984bfd99c234d91386792", null ],
      [ "kNorthWest", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aaaa67fc18f8f8b0ba3b792b46a1fa0c872", null ],
      [ "kNoDirection", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aaa87e054da76bada3343762974c988e80a", null ],
      [ "kNumberOfDirections", "geoconstants_8h.html#a224b9163917ac32fc95a60d8c1eec3aaabdba6353397f1b1654328de91f17e348", null ]
    ] ],
    [ "Orientation", "geoconstants_8h.html#a871118a09520247c78a71ecd7b0abd58", [
      [ "kHorizontal", "geoconstants_8h.html#a871118a09520247c78a71ecd7b0abd58ad4149164ae4bf90011d92a3dbfcce742", null ],
      [ "kVertical", "geoconstants_8h.html#a871118a09520247c78a71ecd7b0abd58a4764485d9d221af213bf2b2769cdfc54", null ],
      [ "kNumberOfOrientations", "geoconstants_8h.html#a871118a09520247c78a71ecd7b0abd58a231632c3d1e6d53428167283534f1abe", null ]
    ] ],
    [ "toOpposite", "geoconstants_8h.html#aff2eb279b5ae69049a3283a004a0fce2", null ],
    [ "toOrientation", "geoconstants_8h.html#a94f8ae4df9a9950ee4332d29456d12e9", null ],
    [ "toOrthogonalOrientation", "geoconstants_8h.html#a1f7b523a922afe5e4fc87ecc6dfd2a7d", null ]
];