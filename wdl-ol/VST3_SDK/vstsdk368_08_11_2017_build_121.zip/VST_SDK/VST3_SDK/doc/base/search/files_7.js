var searchData=
[
  ['smartpointer_2eh',['smartpointer.h',['../smartpointer_8h.html',1,'']]]
];
