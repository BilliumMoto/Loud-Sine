var searchData=
[
  ['data',['data',['../classSteinberg_1_1FUID.html#a5831f7a540668b040269fcc4a4634a6c',1,'Steinberg::FUID::data()'],['../classSteinberg_1_1UStringBuffer.html#afd98290b12cedfd1ec974a198bc20548',1,'Steinberg::UStringBuffer::data()']]]
];
