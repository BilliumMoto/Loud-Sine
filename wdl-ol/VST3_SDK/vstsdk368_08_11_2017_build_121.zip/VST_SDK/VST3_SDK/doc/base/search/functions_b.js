var searchData=
[
  ['makecolorspec',['MakeColorSpec',['../namespaceSteinberg.html#a09d4d9d1e784a8c828716951dd2dbaed',1,'Steinberg::MakeColorSpec(ColorComponent r, ColorComponent g, ColorComponent b)'],['../namespaceSteinberg.html#a921b4c66c57a500044bf0d277304d6dd',1,'Steinberg::MakeColorSpec(ColorComponent r, ColorComponent g, ColorComponent b, ColorComponent a)']]],
  ['max',['Max',['../namespaceSteinberg.html#a0f480f7384f085c2606eff5f310ad194',1,'Steinberg']]],
  ['min',['Min',['../namespaceSteinberg.html#affba9ed0dfe13309d79094f10bbc6021',1,'Steinberg']]]
];
