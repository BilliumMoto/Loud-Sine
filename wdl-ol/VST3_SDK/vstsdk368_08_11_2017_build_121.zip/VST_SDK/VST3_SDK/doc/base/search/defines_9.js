var searchData=
[
  ['tstrbuffersize',['tStrBufferSize',['../fstrdefs_8h.html#a237b89af6a40bef74dff5b5e67efae92',1,'fstrdefs.h']]]
];
