var searchData=
[
  ['iidequal',['iidEqual',['../namespaceSteinberg_1_1FUnknownPrivate.html#aa492cc7f50f5f6bfb7bd727a115e211e',1,'Steinberg::FUnknownPrivate']]],
  ['initialize',['initialize',['../classSteinberg_1_1IPluginBase.html#a3c81be4ff2e7bbb541d3527264f26eed',1,'Steinberg::IPluginBase']]],
  ['instance',['instance',['../classSteinberg_1_1ConstStringTable.html#a7ed68ef8938393b1fc911313db64c804',1,'Steinberg::ConstStringTable']]],
  ['iptr',['IPtr',['../classSteinberg_1_1IPtr.html#a1319c719fbf775d7b691de74c00f7e74',1,'Steinberg::IPtr::IPtr(I *ptr, bool addRef=true)'],['../classSteinberg_1_1IPtr.html#ab923ee4e03558fb6defc4420d53a2a09',1,'Steinberg::IPtr::IPtr(const IPtr &amp;)'],['../classSteinberg_1_1IPtr.html#aded3f51510240b387624e8d2b7a595aa',1,'Steinberg::IPtr::IPtr(const IPtr&lt; T &gt; &amp;other)'],['../classSteinberg_1_1IPtr.html#a0febc1cfbd249e5c625f0accf3879f2a',1,'Steinberg::IPtr::IPtr()'],['../classSteinberg_1_1IPtr.html#ad90cd5b534f50a950d3a2faca6dc077d',1,'Steinberg::IPtr::IPtr(const IPtr&lt; I &gt; &amp;other)']]],
  ['isapproximateequal',['IsApproximateEqual',['../namespaceSteinberg.html#af300911d7995de5985af548ee4eadcf4',1,'Steinberg']]],
  ['isempty',['isEmpty',['../classSteinberg_1_1FVariant.html#a479432127ee77145cc19d6a2d1590821',1,'Steinberg::FVariant']]],
  ['isowner',['isOwner',['../classSteinberg_1_1FVariant.html#a6c975d7981c86e14801166e34183eec7',1,'Steinberg::FVariant']]],
  ['isplatformtypesupported',['isPlatformTypeSupported',['../classSteinberg_1_1IPlugView.html#abcfa60e135807caa316f3915622d9488',1,'Steinberg::IPlugView']]],
  ['isstring',['isString',['../classSteinberg_1_1FVariant.html#a3ea0b05483601e9acd735f48ccf7ed80',1,'Steinberg::FVariant']]],
  ['isvalid',['isValid',['../classSteinberg_1_1FUID.html#aac1b70a2ed67ead038c4d3f5ac4d8a81',1,'Steinberg::FUID']]],
  ['iswidestring',['isWideString',['../classSteinberg_1_1IString.html#a9897ca3a2a9047af3500188209b71ab7',1,'Steinberg::IString']]]
];
