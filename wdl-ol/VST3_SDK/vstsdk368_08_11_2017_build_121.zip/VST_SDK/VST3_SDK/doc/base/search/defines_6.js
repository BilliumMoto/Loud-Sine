var searchData=
[
  ['licence_5fuid',['LICENCE_UID',['../ipluginbase_8h.html#a15eabd5eb49e5ec7c8e2f6210f53ffdc',1,'ipluginbase.h']]]
];
