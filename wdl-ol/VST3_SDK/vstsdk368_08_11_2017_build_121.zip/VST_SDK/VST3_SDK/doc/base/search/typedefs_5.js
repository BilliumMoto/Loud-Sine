var searchData=
[
  ['scalefactor',['ScaleFactor',['../classSteinberg_1_1IPlugViewContentScaleSupport.html#a75ec4b5d086d2af3733ac3775ab008d8',1,'Steinberg::IPlugViewContentScaleSupport']]],
  ['string',['String',['../classSteinberg_1_1FUID.html#a0f2fc16d77666544de6fbd65e184ced8',1,'Steinberg::FUID']]]
];
