var searchData=
[
  ['normalizealpha',['NormalizeAlpha',['../namespaceSteinberg.html#a3e48f70b4cb563c93848c357efc48efd',1,'Steinberg']]],
  ['normalizecolorcomponent',['NormalizeColorComponent',['../namespaceSteinberg.html#afd838e124bec32788d0ec8efafe64a7e',1,'Steinberg']]]
];
