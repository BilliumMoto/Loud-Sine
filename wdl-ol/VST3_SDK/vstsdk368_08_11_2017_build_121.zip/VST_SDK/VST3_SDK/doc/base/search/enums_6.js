var searchData=
[
  ['standardcolor',['StandardColor',['../namespaceSteinberg.html#acbbce6877e30abdb4f8fedfbcc3622cd',1,'Steinberg']]]
];
