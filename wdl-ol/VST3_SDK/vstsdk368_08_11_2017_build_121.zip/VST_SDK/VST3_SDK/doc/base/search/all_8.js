var searchData=
[
  ['how_20to_20derive_20a_20class_20from_20an_20interface',['How to derive a class from an interface',['../howtoClass.html',1,'']]],
  ['how_20the_20host_20will_20load_20a_20plug_2din',['How the host will load a Plug-in',['../loadPlugin.html',1,'']]]
];
