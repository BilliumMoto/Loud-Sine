var searchData=
[
  ['sdkversion',['sdkVersion',['../structSteinberg_1_1PClassInfo2.html#aefe2ed287dcf207d4f83b335ed2b78f5',1,'Steinberg::PClassInfo2::sdkVersion()'],['../structSteinberg_1_1PClassInfoW.html#a2fb55f1840c1948ff8added4e4775684',1,'Steinberg::PClassInfoW::sdkVersion()']]],
  ['string16',['string16',['../classSteinberg_1_1FVariant.html#a1264080af4e6271f01c888cc93953194',1,'Steinberg::FVariant']]],
  ['string8',['string8',['../classSteinberg_1_1FVariant.html#adeedacf549c7fcf04323ea19dfa84244',1,'Steinberg::FVariant']]],
  ['subcategories',['subCategories',['../structSteinberg_1_1PClassInfo2.html#a106c76c37c57aa35e42654278412ee90',1,'Steinberg::PClassInfo2::subCategories()'],['../structSteinberg_1_1PClassInfoW.html#a106c76c37c57aa35e42654278412ee90',1,'Steinberg::PClassInfoW::subCategories()']]]
];
