var searchData=
[
  ['viewrect',['ViewRect',['../structSteinberg_1_1ViewRect.html',1,'Steinberg']]]
];
