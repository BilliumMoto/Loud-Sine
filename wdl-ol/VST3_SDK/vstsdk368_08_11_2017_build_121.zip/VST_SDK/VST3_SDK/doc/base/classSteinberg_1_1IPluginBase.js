var classSteinberg_1_1IPluginBase =
[
    [ "initialize", "classSteinberg_1_1IPluginBase.html#a3c81be4ff2e7bbb541d3527264f26eed", null ],
    [ "terminate", "classSteinberg_1_1IPluginBase.html#a1563a6e0e622483924e5f21242407f16", null ]
];