var classSteinberg_1_1IUpdateHandler =
[
    [ "addDependent", "classSteinberg_1_1IUpdateHandler.html#a7ab1193e35e93559ccb0ebc3dd1925eb", null ],
    [ "removeDependent", "classSteinberg_1_1IUpdateHandler.html#a0a393e93442f393b55deb0e183bfc66a", null ],
    [ "triggerUpdates", "classSteinberg_1_1IUpdateHandler.html#a5df36e1fc97bddca8eaabc6b39de6530", null ],
    [ "deferUpdates", "classSteinberg_1_1IUpdateHandler.html#a161a23aead9a302f8b4b2021d8553e29", null ]
];