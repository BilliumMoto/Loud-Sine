var ipluginbase_8h =
[
    [ "PClassInfoW", "structSteinberg_1_1PClassInfoW.html", "structSteinberg_1_1PClassInfoW" ],
    [ "LICENCE_UID", "ipluginbase_8h.html#a15eabd5eb49e5ec7c8e2f6210f53ffdc", null ],
    [ "GetFactoryProc", "ipluginbase_8h.html#acdf055c3f848689878f8d7cdccac3406", null ],
    [ "GetPluginFactory", "group__pluginBase.html#ga843ac97a36dfc717dadaa7192c7e8330", null ]
];