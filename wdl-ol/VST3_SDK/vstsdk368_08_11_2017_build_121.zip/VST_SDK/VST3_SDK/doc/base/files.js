var files =
[
    [ "conststringtable.cpp", "conststringtable_8cpp.html", null ],
    [ "conststringtable.h", "conststringtable_8h.html", [
      [ "ConstStringTable", "classSteinberg_1_1ConstStringTable.html", "classSteinberg_1_1ConstStringTable" ]
    ] ],
    [ "coreiids.cpp", "coreiids_8cpp.html", null ],
    [ "doc.h", "doc_8h.html", null ],
    [ "falignpop.h", "falignpop_8h.html", null ],
    [ "falignpush.h", "falignpush_8h.html", null ],
    [ "fplatform.h", "fplatform_8h.html", "fplatform_8h" ],
    [ "fstrdefs.h", "fstrdefs_8h.html", "fstrdefs_8h" ],
    [ "ftypes.h", "ftypes_8h.html", "ftypes_8h" ],
    [ "funknown.cpp", "funknown_8cpp.html", "funknown_8cpp" ],
    [ "funknown.h", "funknown_8h.html", "funknown_8h" ],
    [ "futils.h", "futils_8h.html", "futils_8h" ],
    [ "fvariant.h", "fvariant_8h.html", "fvariant_8h" ],
    [ "geoconstants.h", "geoconstants_8h.html", "geoconstants_8h" ],
    [ "ibstream.h", "ibstream_8h.html", null ],
    [ "icloneable.h", "icloneable_8h.html", [
      [ "ICloneable", "classSteinberg_1_1ICloneable.html", "classSteinberg_1_1ICloneable" ]
    ] ],
    [ "ierrorcontext.h", "ierrorcontext_8h.html", [
      [ "IErrorContext", "classSteinberg_1_1IErrorContext.html", "classSteinberg_1_1IErrorContext" ]
    ] ],
    [ "ipersistent.h", "ipersistent_8h.html", "ipersistent_8h" ],
    [ "ipluginbase.h", "ipluginbase_8h.html", "ipluginbase_8h" ],
    [ "iplugview.h", "iplugview_8h.html", "iplugview_8h" ],
    [ "iplugviewcontentscalesupport.h", "iplugviewcontentscalesupport_8h.html", null ],
    [ "istringresult.h", "istringresult_8h.html", [
      [ "IStringResult", "classSteinberg_1_1IStringResult.html", "classSteinberg_1_1IStringResult" ],
      [ "IString", "classSteinberg_1_1IString.html", "classSteinberg_1_1IString" ]
    ] ],
    [ "iupdatehandler.h", "iupdatehandler_8h.html", [
      [ "IUpdateHandler", "classSteinberg_1_1IUpdateHandler.html", "classSteinberg_1_1IUpdateHandler" ],
      [ "IDependent", "classSteinberg_1_1IDependent.html", "classSteinberg_1_1IDependent" ]
    ] ],
    [ "keycodes.h", "keycodes_8h.html", "keycodes_8h" ],
    [ "pluginbasefwd.h", "pluginbasefwd_8h.html", null ],
    [ "smartpointer.h", "smartpointer_8h.html", "smartpointer_8h" ],
    [ "ucolorspec.h", "ucolorspec_8h.html", "ucolorspec_8h" ],
    [ "ustring.cpp", "ustring_8cpp.html", "ustring_8cpp" ],
    [ "ustring.h", "ustring_8h.html", "ustring_8h" ]
];